﻿angular.module('gridTaskApp')
	.constant("classes", {
		menuDown: 'icon-menu-down',
		menuUp: 'icon-menu-up'
	});