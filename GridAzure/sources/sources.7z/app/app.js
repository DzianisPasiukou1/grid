﻿angular.module('gridTaskApp', ['ngGrid', 'ui.grid', 'ui.grid.selection', 'ui.grid.expandable'])
	.value('templatesPath', 'app/templates/');
