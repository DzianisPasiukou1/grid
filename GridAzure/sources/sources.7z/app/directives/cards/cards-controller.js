﻿angular.module('gridTaskApp')
	.controller('cardsCtrl', ['$scope', function ($scope) {

	}]);