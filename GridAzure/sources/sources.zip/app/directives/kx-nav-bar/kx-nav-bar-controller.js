﻿angular.module('gridTaskApp')
	.controller('kxNavBarCtrl', ['$scope', function ($scope) {

	}]);