﻿angular.module('gridTaskApp')
	.controller('pageCtrl', ['$scope', function ($scope) {
	}]);