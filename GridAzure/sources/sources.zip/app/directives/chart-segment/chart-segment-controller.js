﻿angular.module('gridTaskApp')
	.controller('chartSegmentCtrl', ['$scope', function ($scope) {

	}]);