﻿angular.module('gridTaskApp')
	.controller('coreDiagramCtrl', ['$scope', function ($scope) {

	}]);