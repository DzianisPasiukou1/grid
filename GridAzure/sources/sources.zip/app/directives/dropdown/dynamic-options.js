﻿var Dynamic_Options = (function () {
	function Dynamic_Options(origOpt, elemWidth, elemOffset) {

	}

	return Dynamic_Options;
})();