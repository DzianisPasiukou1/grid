﻿angular.module('gridTaskApp')
	.directive('download', ['templatesPath', function (templatesPath) {

	}]);