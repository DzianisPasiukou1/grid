﻿angular.module('gridTaskApp', ['ngGrid'])
	.value('templatesPath', 'app/templates/')
	.value('jsonPath', 'data/');
