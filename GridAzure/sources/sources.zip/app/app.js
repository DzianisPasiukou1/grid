﻿angular.module('gridTaskApp', ['ngGrid'])
	.value('templatesPath', 'app/templates/');