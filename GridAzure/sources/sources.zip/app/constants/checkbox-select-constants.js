﻿angular.module('gridTaskApp')
	 .constant("checkboxSelectConstants",
	 {
	 	values: {
	 		all: { label: 'All' },
	 		noOne: { label: 'No one' },
	 		marked: { label: 'Marked' },
	 		notMarked: { label: 'Not marked' }
	 	}
	 });